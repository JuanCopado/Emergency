# Cardiovascular modules

Shared gate: establish ABC status, perfusion, symptom onset, ECG timing, vascular
access, glucose, pregnancy possibility, bleeding risk, renal function and current
antithrombotic therapy. Use serial examinations; a single normal ECG, troponin or
POCUS study does not exclude time-critical disease.

## acute-coronary-syndrome

- Threats: STEMI/occlusion MI, shock, malignant arrhythmia and mechanical complication.
- Obtain ECG promptly and repeat with recurrent symptoms; add posterior/right-sided leads when indicated. Use serial high-sensitivity troponin without delaying reperfusion.
- Activate the local reperfusion pathway for diagnostic ST elevation or equivalent. Verify current antiplatelet, anticoagulant and fibrinolysis criteria before dosing.
- Treat hypoxemia, instability and pain; avoid routine oxygen in normoxemia. Reassess rhythm, perfusion and complications; monitored admission or immediate cath-lab transfer as indicated.

## pulmonary-embolism

- Classify hemodynamic instability first; consider PE, ACS, aortic disease, tamponade and sepsis in parallel.
- Use validated pretest probability, PERC only in appropriate very-low-risk patients, D-dimer when indicated, and CTPA/VQ according to probability and contraindications.
- In shock, bedside echo/venous ultrasound may support an emergency pathway but cannot independently exclude PE.
- Verify current anticoagulation, systemic thrombolysis, catheter/surgical reperfusion criteria, contraindications and doses. Escalate high-risk or deteriorating patients immediately.

## arrhythmias-cardiac-arrest

- Shared router and safety gate only. Identify age group, pulse, instability and goals of care; call the resuscitation team and use the current local/ERC pathway.
- Select `adult-arrhythmias` or `pediatric-arrhythmias` for a perfusing rhythm; select `adult-cardiac-arrest` or `pediatric-cardiac-arrest` for pulselessness. For a child in arrest, use pediatric-specific care; newborn resuscitation at birth is outside these modules.
- Do not transfer adult energy, drug dose, airway or compression settings to a child. A pulseless rhythm requires the arrest pathway, not synchronized cardioversion. Do not treat an irregular broad-complex rhythm reflexively; suspected pre-excited atrial fibrillation needs expert rhythm-specific care. Avoid reflex adenosine or AV-nodal blockade.
- Treat reversible causes, reassess after each intervention and transition to the matching post-resuscitation pathway.

## adult-arrhythmias

- Confirm pulse, ABC compromise and life-threatening features (shock, syncope, ongoing ischemia, severe heart failure); attach monitor/defibrillator, obtain IV access and 12-lead ECG if this does not delay treatment. Correct hypoxia, ischemia, electrolyte, temperature and toxicologic causes.
- Unstable tachyarrhythmia with a pulse: synchronized cardioversion; sedate if feasible without delaying shock. If synchronization is unavailable or the patient becomes pulseless, follow the adult arrest/defibrillation algorithm. Stable regular narrow-complex tachycardia: vagal maneuvers then protocol-based adenosine; irregular or broad-complex rhythms require rhythm-specific expert-guided treatment.
- Unstable bradycardia: treat reversible causes, prepare transcutaneous pacing and follow adult bradyarrhythmia escalation (including chronotropic infusion or expert transvenous pacing where indicated). Do not delay pacing for repeated ineffective drugs in a deteriorating patient.
- Avoid AV-nodal blockers in pre-excited atrial fibrillation; avoid reflex adenosine in irregular broad-complex tachycardia. For torsades, long-QT, toxicologic or device-related rhythms, use the matching special-circumstance pathway and verify drug/electrical details against current ERC/local protocol.
- After conversion, document rhythm, cause, recurrence risk and disposition; seek cardiology input for new, recurrent, wide-complex or structurally associated arrhythmia.

## adult-cardiac-arrest

- Adult ALS pathway: recognize unresponsiveness with absent/abnormal breathing, call the resuscitation team, start high-quality CPR, attach defibrillator and minimize pauses. Confirm arrest rapidly; do not delay compressions for monitor leads, IV access or airway procedures.
- Classify rhythm as shockable (VF/pulseless VT) or non-shockable (PEA/asystole). Defibrillate shockable rhythms and immediately resume CPR; continue 2-minute cycles with rhythm checks and protocol-timed drugs. For non-shockable rhythm, continue CPR, give protocol-timed vasopressor and search/treat reversible causes. Use current ERC 2025/local sequence and doses; do not mix algorithms.
- Use waveform capnography when advanced airway is placed; prioritize uninterrupted compressions and ventilation without hyperventilation. POCUS only by a trained operator during planned pauses and never to prolong a pulse check. Consider mechanical cause, hypoxia, hypovolemia, electrolyte/metabolic disorder, hypothermia, tension pneumothorax, tamponade, toxins, pulmonary/coronary thrombosis.
- For ROSC, transition immediately to post-arrest care: controlled oxygen/ventilation, hemodynamic stabilization, 12-lead ECG and cause-directed coronary/neuro/critical care evaluation. If no ROSC, continue the algorithm and use current termination/transport policy; do not use a single factor as a termination rule.

## undifferentiated-shock

- Treat shock as a perfusion emergency: ABCDE, call for senior/resuscitation support, monitor ECG/BP/SpO2/temperature, obtain IV/IO access, bedside glucose, blood gas/lactate, CBC, electrolytes/renal function, cultures when infection plausible and crossmatch when bleeding possible. Do not wait for hypotension or a lactate threshold if organ hypoperfusion is evident.
- Classify the working physiology while treating in parallel: hypovolemic/hemorrhagic; distributive (septic, anaphylactic, neurogenic or adrenal); cardiogenic; obstructive (massive PE, tamponade, tension pneumothorax); or mixed. Reassess mental status, capillary refill, skin temperature, pulse pressure, urine output and lactate trend; one normal value or a negative limited POCUS does not exclude shock.
- Use focused cardiac, lung, IVC/venous and abdominal POCUS only as an adjunct to history/examination and formal imaging; identify ventricular failure, congestion, pericardial effusion, pneumothorax, free fluid and likely source. Search for bleeding, infection/source, ischemia/arrhythmia, medication/toxin, pregnancy-related cause and endocrine crisis.
- Give fluid only when likely responsive and not congested; use small reassessed aliquots when phenotype is uncertain. Hemorrhage needs blood-product/source-control pathway, not repeated crystalloid. Start syndrome-concordant vasopressor/source control early for persistent distributive shock; avoid blindly starting sepsis or cardiogenic treatment for undifferentiated physiology.
- Route to the supported cause: `sepsis-shock`, `cardiogenic-shock`, `trauma-major-hemorrhage`, `anaphylaxis`, `pulmonary-embolism`, `cardiac-tamponade-pericardial-emergency`, `tension-pneumothorax`, `adrenal-crisis`, or `obstetric-emergencies`. Consider neurogenic shock only after hemorrhage and other causes are addressed. Load `pediatric-shock` for children; neonates and burns require their specific pathways.

## hypertensive-emergencies

- Diagnose acute hypertension-mediated organ injury, not a number alone; severe BP without acute organ injury is not by itself a hypertensive emergency. Assess neurologic, cardiac, aortic, renal, retinal and pregnancy complications.
- Select titratable IV therapy and the reduction target for the specific syndrome. For many hypertensive emergencies, reduce MAP by no more than about 20--25% in the first hour, then reassess; do not transfer this general rule to aortic dissection, acute stroke, pulmonary edema, ACS or pre-eclampsia/eclampsia, which have different targets and timing.
- Avoid abrupt uncontrolled reductions. Verify agent-specific contraindications, infusion math and local targets; use continuous monitoring and frequent neurologic/perfusion reassessment.

## iv-antihypertensive-selection

- First identify the hypertension-mediated organ injury and its target; there is no universal substitute for nicardipine. State the current BP, desired range, maximum initial reduction, lower perfusion boundary, monitoring and reassessment interval. Severe asymptomatic hypertension without acute organ injury does not justify rapid IV lowering.
- Nimodipine is not an alternative IV antihypertensive. It is disease-modifying enteral treatment after confirmed aneurysmal subarachnoid hemorrhage and can itself cause hypotension; do not substitute it for nicardipine in ICH, ischemic stroke, hypertensive encephalopathy, aortic syndrome, ACS or pulmonary edema.
- **Labetalol** is a practical alternative for many neurologic hypertensive emergencies when bradycardia, high-grade AV block, decompensated systolic failure and active bronchospasm are absent. Give 20 mg IV slowly over 2 minutes; if needed, use protocol-based additional 40--80 mg doses at about 10-minute intervals to a usual cumulative ceiling of 300 mg. For a continuous infusion, the labelled preparation 200 mg/200 mL = 1 mg/mL; 0.5 mg/min = 30 mL/h, 1 mg/min = 60 mL/h and 2 mg/min = 120 mL/h. A 100 mg/100 mL bag gives the same concentration and rates only when pharmacy/local compatibility is confirmed. Monitor ECG/BP and hold for hypotension, bradycardia, block, bronchospasm or worsening pump failure.
- **Clevidipine** is a short-acting arterial alternative when available. Use the ready-to-use 0.5 mg/mL lipid emulsion without dilution: 1 mg/h = 2 mL/h and 2 mg/h = 4 mL/h. The product label permits initial doubling at 90-second intervals; as BP approaches target, use smaller increases and extend adjustments to every 5--10 minutes. Most patients in trials received no more than 16 mg/h = 32 mL/h; the label limits 24-hour exposure because of lipid load (no more than 1,000 mL or an average 21 mg/h). Do not use with soy/egg allergy, defective lipid metabolism or severe aortic stenosis; use strict asepsis, discard an opened vial according to the label, and account for lipid calories.
- **Acute aortic syndrome:** reduce impulse first with esmolol or labetalol when beta-blockade is safe. Only if BP remains high after rate/impulse control add nicardipine, clevidipine or another protocol-approved vasodilator. Never start a pure vasodilator first in a tachycardic patient; use IV diltiazem/verapamil for rate control only when beta-blockers are contraindicated and the aortic/cardiac phenotype permits.
- **Hypertensive pulmonary edema or ACS:** a titratable nitrate is usually more syndrome-concordant than nicardipine. If a pharmacy-approved concentration is 20 mg/100 mL or 40 mg/200 mL = 200 micrograms/mL, 5 micrograms/min = 1.5 mL/h and 10 micrograms/min = 3 mL/h; titrate every 3--5 minutes to symptoms, BP and local ceiling. Do not use with hypotension, preload-dependent/right-ventricular infarction, recent PDE-5 inhibitor or critical stenotic/preload-dependent physiology. Higher-dose pulmonary-edema strategies require the local protocol and continuous monitoring.
- **Pregnancy/postpartum severe hypertension:** use the pregnancy pathway. First-line urgent options are IV labetalol, IV hydralazine or immediate-release oral nifedipine; do not use sublingual nifedipine. Magnesium sulfate is for seizure prevention/treatment, not BP lowering.
- **Sympathetic/toxicologic crisis:** treat agitation, pain and the driver first; benzodiazepines and a cause-appropriate vasodilator may be required. Do not use isolated beta-blockade in acute cocaine/amphetamine toxicity or catecholamine excess without specialist/toxicology guidance.
- Reserve sodium nitroprusside for selected monitored rescue situations when preferred agents are unavailable or ineffective. Its toxicity/monitoring burden and potential problems in raised ICP, renal/hepatic failure and pregnancy make it a poor routine substitute. Enalaprilat and hydralazine outside pregnancy have less predictable/prolonged effects and are not default choices when minute-to-minute titration is needed.

## non-coronary-chest-pain

- Exclude ACS, aortic syndrome, PE, pneumothorax, tamponade, esophageal rupture and dangerous abdominal causes before assigning a benign diagnosis.
- Integrate onset, radiation, associated symptoms, pulse/pressure asymmetry, ECG, troponin, radiography and targeted POCUS/imaging.
- Do not use pain character or reproducibility alone to exclude serious disease. Discharge only with stable serial assessment, explicit return precautions and follow-up.

## acute-heart-failure

- Identify pulmonary edema, hypoxemia, shock, ACS, arrhythmia, mechanical/valvular cause and precipitant.
- Use lung/cardiac POCUS, ECG, radiography and biomarkers in context. NIV may help appropriate pulmonary edema; avoid it when airway protection or shock makes it unsafe.
- Give oxygen for hypoxemia rather than routinely. Use IV loop diuretic for clinically significant congestion; consider a titratable vasodilator when BP is adequate, especially in hypertensive pulmonary edema. Do not use inotropes routinely: reserve them for low-output hypoperfusion after correcting reversible causes; use norepinephrine preferentially when vasopressor support is required.
- Before nitrates, diuresis or positive-pressure ventilation, look for critical aortic stenosis, right-ventricular infarction, obstructive shock and preload dependence. Choose therapy from congestion, blood pressure and perfusion rather than the label of heart failure alone.
- Track work of breathing, urine output, renal function, electrolytes and perfusion; admit high-risk patients and escalate shock or respiratory failure.

## cardiogenic-shock

- Recognize shock from hypoperfusion plus a primary cardiac pump problem; hypotension may be absent early. Record a SCAI stage and trend mental status, skin/peripheral perfusion, urine output, lactate, acid-base state and vasoactive requirement rather than relying on one blood-pressure value.
- Activate a shock/cardiology pathway early. Obtain ECG, serial troponin, blood gas/lactate, full blood count, electrolytes, renal/hepatic function and urgent echocardiography. Use POCUS to identify ventricular phenotype, congestion and a possible mechanical lesion, but obtain expert echocardiography and invasive hemodynamics when the phenotype or response remains uncertain.
- Treat the cause immediately: activate reperfusion for acute MI; correct unstable arrhythmia; seek urgent structural/cardiothoracic treatment for papillary-muscle, septal, free-wall or valve catastrophe; and distinguish obstructive shock (PE, tamponade, tension pneumothorax) because its definitive treatment differs.
- Give oxygen only for hypoxemia and choose ventilatory support cautiously because induction and positive pressure can precipitate collapse. Do not give automatic large fluid boluses. If true hypovolemia or preload-dependent right-ventricular shock is plausible, use a small test bolus (for example 250 mL balanced crystalloid) with immediate lung, venous-congestion and perfusion reassessment; stop if congestion worsens or perfusion does not improve.
- When hypotension threatens perfusion, norepinephrine is a reasonable first inopressor while the cause is treated. Example preparation: norepinephrine 8 mg to a final volume of 100 mL = 80 micrograms/mL (or 8 mg/200 mL = 40 micrograms/mL). A local starting range of 0.02--0.1 micrograms/kg/min must be individualized. Pump rate = dose (micrograms/kg/min) x weight (kg) x 60 / concentration (micrograms/mL). At 80 kg and 0.05 micrograms/kg/min: 3 mL/h with 8 mg/100 mL or 6 mL/h with 8 mg/200 mL. Titrate every 2--5 minutes to an individualized MAP/perfusion target (often initially MAP at least 65 mm Hg), recording rhythm, extremity perfusion, urine output and lactate; use the local maximum and central/peripheral-line policy.
- Add an inotrope only for persistent low-output hypoperfusion after pressure, rhythm, preload and reversible cause have been addressed. Example dobutamine: 250 mg/100 mL = 2,500 micrograms/mL (or 250 mg/200 mL = 1,250 micrograms/mL); 2.5--5 micrograms/kg/min is a common starting range. At 80 kg, 2.5 micrograms/kg/min = 4.8 mL/h with 250 mg/100 mL or 9.6 mL/h with 250 mg/200 mL. Titrate to perfusion/cardiac output and stop or reduce for tachyarrhythmia, ischemia or worsening hypotension. Milrinone is not a default substitute in hypotensive or renally impaired patients because vasodilation and accumulation can be harmful.
- Do not use epinephrine, dopamine, dual inotropes or temporary mechanical circulatory support reflexively. Escalate deteriorating SCAI C--E shock to a multidisciplinary shock team/advanced center for phenotype-guided invasive monitoring and device selection; device benefit and harm depend on cause, timing, ventricular phenotype, bleeding/vascular risk and recovery or destination strategy.
- Reassess at least every 5--15 minutes during escalation: MAP and pulse pressure, rhythm, oxygenation/ventilation, capillary refill/temperature gradient, urine output, lactate trajectory and drug/device complications. Transfer to a cardiac ICU or shock-capable center; a transient BP response is not resolution.

## acute-aortic-syndrome

- Suspect dissection, intramural hematoma or penetrating aortic ulcer with abrupt severe chest/back/abdominal pain, pulse or pressure asymmetry, focal neurologic deficit, syncope, acute aortic regurgitation, malperfusion or otherwise unexplained shock. Pain character, a normal chest radiograph, normal pulses or an initial nondiagnostic POCUS cannot exclude it.
- Place two large-bore IV lines, continuous ECG/SpO2 monitoring and an arterial line when this will not delay definitive care. Obtain type and crossmatch, full blood count, renal function, lactate and ECG/troponin while activating an aortic/cardiothoracic team. Do not give anticoagulation or fibrinolysis for presumed ACS until acute aortic syndrome has been considered and reasonably excluded when clinical suspicion is meaningful.
- If stable enough, obtain urgent ECG-gated CT angiography from chest through pelvis with branch-vessel assessment. In an unstable patient who cannot safely leave resuscitation, use immediate expert TEE when available to guide transfer to the operating room; POCUS may identify pericardial effusion, severe aortic regurgitation or root dilatation but cannot rule out dissection.
- Start analgesia and anti-impulse therapy while arranging definitive treatment. Target HR 60--80/min and SBP below 120 mm Hg, or the lowest pressure that preserves cerebral, coronary and end-organ perfusion. Use an IV beta-blocker first unless shock, severe bradycardia/AV block, acute severe aortic regurgitation or another contraindication is present; never apply a BP-lowering target to a hypotensive, rupturing or malperfused patient.
- Esmolol reference preparation: 2 g to a final volume of 100 mL = 20 mg/mL. A cautious infusion may start at 50 micrograms/kg/min and be titrated every 4--5 minutes; a 500 micrograms/kg loading dose over 1 minute is optional and should be omitted when hemodynamics are tenuous. Pump rate = dose (micrograms/kg/min) x weight x 60 / 20,000. At 80 kg: 50 micrograms/kg/min = 12 mL/h; 100 micrograms/kg/min = 24 mL/h. Verify the local ceiling (commonly 200--300 micrograms/kg/min), formulation and contraindications.
- Labetalol alternative when appropriate: 10--20 mg IV over 2 minutes, repeated according to response, or the labelled 200 mg/200 mL = 1 mg/mL infused at 0.5--2 mg/min = 30--120 mL/h. Avoid in bradycardia, high-grade block, decompensated pump failure or active bronchospasm. If BP remains above target only after rate/impulse control, add a titratable vasodilator. Nicardipine 20 mg/100 mL = 0.2 mg/mL: start 5 mg/h = 25 mL/h, increase by 2.5 mg/h = 12.5 mL/h every 5--15 minutes to a usual maximum 15 mg/h = 75 mL/h; follow local formulation and stop for hypoperfusion. If nicardipine is unavailable, clevidipine may be used with the `iv-antihypertensive-selection` ready-to-use concentration and safety gates. Never start a pure vasodilator before impulse control when tachycardia is present.
- Acute type A dissection needs immediate operative repair. Complicated acute type B disease (rupture, malperfusion/branch occlusion, extension, progressive enlargement, refractory pain or uncontrolled hypertension) needs urgent aortic intervention, usually endovascular when anatomy permits; uncomplicated type B disease begins with monitored anti-impulse therapy and specialist surveillance.
- Reassess pain, neurologic status, limb/mesenteric/renal perfusion, urine output, lactate, HR and BP continuously. New hypotension, pericardial effusion/tamponade, ischemia or neurologic deficit is deterioration, not successful BP control.

## cardiac-tamponade-pericardial-emergency

- Treat tamponade as obstructive shock caused by pressure, rate of fluid accumulation and ventricular interaction, not by effusion size alone. Hypotension, raised venous pressure, tachycardia, pulsus paradoxus, narrow pulse pressure or PEA may occur, but the classic triad is insensitive and a normal BP does not exclude compensated tamponade.
- Perform immediate focused cardiac ultrasound while resuscitation continues: assess effusion distribution, right-atrial systolic and right-ventricular diastolic collapse, respiratory inflow variation, IVC/venous congestion, ventricular size/function and alternative causes of shock. POCUS supports physiology but does not by itself determine cause or exclude loculated/postoperative tamponade; obtain expert echo when it will not delay drainage.
- Call cardiology/cardiothoracic surgery and prepare definitive drainage immediately for hemodynamic compromise. Echo- or fluoroscopy-guided pericardiocentesis with catheter drainage is preferred for accessible medical effusion. Surgical drainage is favored for trauma/hemopericardium or clot, suspected type A dissection or free-wall rupture, postoperative/loculated collections, purulent disease or failed/unsafe percutaneous access.
- Bridge only while drainage is being assembled: keep the patient supine if tolerated, give oxygen for hypoxemia and consider 250 mL isotonic crystalloid aliquots only for hypotension without pulmonary congestion, with reassessment after each aliquot. Norepinephrine may support perfusion using the `cardiogenic-shock` preparation and calculation, but fluids and vasoactive drugs must not delay decompression.
- Avoid nitrates, diuretics and other preload reduction. Avoid sedation, induction and positive-pressure ventilation if possible because loss of sympathetic tone and increased intrathoracic pressure can precipitate arrest. If airway intervention is unavoidable, use the most experienced operator, pre-position drainage/resuscitation capability, preserve spontaneous ventilation when feasible and prepare immediate vasopressor support.
- For percutaneous drainage, use continuous monitoring, sterile technique and real-time imaging to select the shortest safe fluid path; aspirate incrementally, leave a drain when appropriate and confirm hemodynamic/echo response. Stop and escalate for arrhythmia, myocardial/coronary injury, bleeding, pneumothorax, failed aspiration or persistent shock. Send fluid studies targeted to suspected infection, malignancy or inflammatory cause without delaying stabilization.
- In suspected type A dissection with tamponade, do not perform routine complete pericardial drainage: uncontrolled decompression can increase aortic bleeding. Immediate surgery is definitive; only an expert-led controlled small-volume bridge is considered for otherwise fatal peri-arrest collapse when operative transfer is not immediately achievable.
- Reassess BP/pulse pressure, venous pressure, mental status, capillary refill, urine output and echo physiology immediately after drainage. Persistent shock requires evaluation for re-accumulation, clot/loculation, ongoing hemorrhage, ventricular failure, tension pneumothorax or another diagnosis. Admit to a monitored critical-care service and treat the cause.

## critical-valvular-disease

- Suspect acute severe regurgitation, critical stenosis, prosthetic dysfunction or endocarditis when shock/pulmonary edema is disproportionate or a new murmur is present.
- Obtain urgent expert echocardiography; POCUS is a bridge and cannot grade complex lesions reliably.
- In critical aortic stenosis, avoid tachycardia, loss of sinus rhythm, abrupt vasodilation and unstructured preload reduction; preserve coronary perfusion while treating congestion cautiously. Acute severe regurgitation may instead benefit from afterload reduction when BP permits. Do not apply one valve strategy to another.
- Stabilize with immediate cardiology/cardiothoracic input and arrange definitive intervention; drugs and ventilation are bridges, not definitive treatment of a mechanical lesion.

## infective-endocarditis

- Consider with bacteremia, embolic phenomena, new regurgitation, device/prosthetic valve, injection exposure or unexplained sepsis.
- Obtain at least three appropriately collected blood-culture sets before antibiotics when the patient is stable enough; do not delay antimicrobials or resuscitation in septic shock. Avoid drawing all bottles from one existing line unless line infection is the specific question.
- Perform TTE first and pursue TEE when TTE is negative/inconclusive despite suspicion, or when prosthetic valve, intracardiac device or peri-annular complication is possible. Repeat imaging if early studies are nondiagnostic and suspicion remains high.
- Select empiric therapy using valve/device status, acquisition setting, renal function and local microbiology; verify regimen before dosing.
- Activate an endocarditis team where available. Urgently involve cardiology, infectious diseases and surgery for heart failure, uncontrolled infection/abscess, prosthetic or device infection, or high embolic risk; antibiotics alone are not definitive when a surgical indication exists.

## dvt

- Assess PE symptoms and limb threat first. Use validated pretest probability, D-dimer and compression ultrasound appropriately.
- Consider alternative diagnoses and special sites. Verify anticoagulant choice/dose against renal function, weight, pregnancy, cancer, interactions and bleeding risk.
- Escalate phlegmasia, threatened limb, major bleeding risk or suspected PE; ensure follow-up when an initial ultrasound strategy requires repetition.

## device-complications

- Identify the device and indication: pacemaker/ICD, ventricular assist device, vascular device or monitor. Obtain device card/history and specialist interrogation early.
- Threats include failure to capture/sense, inappropriate shock, lead displacement, infection, thrombosis, perforation and device-specific low-flow states.
- Treat the patient and rhythm, not monitor artifacts. Use ECG, radiography and targeted POCUS; consult the implanting/device team and disposition to monitored specialist care when malfunction is possible.
