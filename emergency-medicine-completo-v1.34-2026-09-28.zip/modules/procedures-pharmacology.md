# Procedure and pharmacology modules

Shared gate: verify identity, indication, consent/capacity, monitoring, allergies,
weight, pregnancy, renal/hepatic function, anticoagulation, equipment, skilled help,
rescue plan and post-intervention reassessment.

## airway-rsi

- State the indication and assess anatomic plus physiologic difficulty: hypoxemia, hypotension, metabolic acidosis, right-ventricular failure, raised ICP and upper-GI bleeding. Correct reversible physiology before induction without delaying a crashing airway.
- Conduct a team brief with roles and Plan A/B/C/D. Position appropriately, suction ready, preoxygenate to the highest achievable reserve, use nasal oxygen during attempts when helpful, and prepare two functioning IV/IO routes, vasopressor, rescue supraglottic airway and front-of-neck access.
- Use the device most likely to achieve first-pass success, generally videolaryngoscopy when available and familiar. Limit repeated attempts, reoxygenate between attempts and change operator/device/technique rather than repeating the same failure.
- Use both an induction drug and neuromuscular blocker unless a specific contraindication exists. Common adult reference doses are ketamine 1--2 mg/kg IV, etomidate 0.2--0.3 mg/kg IV, or propofol 0.5--1.5 mg/kg IV selected and reduced for shock/age; plus rocuronium 1.2 mg/kg IV or suxamethonium 1--1.5 mg/kg IV. Verify actual versus ideal/adjusted weight, formulation and contraindications before patient-specific dosing.
- Avoid suxamethonium when hyperkalemia or high-risk potassium release, neuromuscular disease, denervation, significant burns/crush after the vulnerable interval, malignant-hyperthermia susceptibility or relevant contraindication is present. Rocuronium requires a plan for prolonged paralysis and immediate post-intubation sedation.
- Confirm tracheal placement with continuous waveform capnography, then reassess depth, bilateral ventilation, BP and complications. Start analgesia/sedation immediately, set lung-protective ventilation, obtain blood gas/appropriate imaging and document the airway plan.

## sedoanalgesia

- Choose the least depth needed and assess ASA status, airway, aspiration risk, fasting context, pregnancy, age/frailty, prior opioids and cardiorespiratory reserve. Urgent procedures need an explicit risk-benefit decision rather than automatic delay for fasting time.
- Assign a dedicated sedation clinician plus proceduralist and nurse. Use ECG, pulse oximetry, continuous capnography and NIBP; prepare oxygen, suction, bag-mask ventilation, airway adjuncts, vasopressor and reversal agents before dosing.
- Adult reference regimens: ketamine 1 mg/kg IV over 30--60 seconds, repeat 0.25--0.5 mg/kg every 5--10 minutes; propofol 0.5--1 mg/kg IV slowly, repeat 0.5 mg/kg every 3--5 minutes; midazolam 1--2 mg IV over 1--2 minutes with small repeat doses after 2--5 minutes; fentanyl 0.5 mcg/kg IV with another sedative or 0.5--1 mcg/kg when used for analgesia/sedation, repeat no sooner than every 2 minutes. Reduce substantially in older, frail, shocked or opioid-exposed patients.
- Match agent to physiology and procedure: ketamine provides analgesia/dissociation but may increase secretions or sympathetic demand; propofol is not analgesic and can cause apnea/hypotension; midazolam plus opioid has synergistic respiratory depression and delayed effect; local/regional anesthesia reduces sedative requirement.
- Prepare naloxone and flumazenil but prioritize airway/ventilation. Titrate naloxone in 0.1--0.2 mg IV increments to ventilation; flumazenil 0.1--0.2 mg IV every minute to a maximum 1 mg is conditional and may precipitate seizure/withdrawal.
- Record intended and achieved depth, drug/time/dose, capnography and adverse events. Continue observation until baseline mental status, stable vitals, airway independence, pain/nausea control and safe discharge/admission criteria are met.

## empiric-antibiotics

- Define syndrome/source, severity, immune status, allergies, renal/hepatic function, recent antibiotics, prior cultures and MDR risk.
- Obtain cultures when useful without delaying treatment in shock or other time-critical infection.
- Use local formulary/antibiogram for agent choice; verify loading and maintenance dose, infusion strategy and renal adjustment. Document indication, review time and source-control plan; narrow or stop when data support it.

## anticoagulation-reversal

- Identify agent, last dose, indication, renal function, bleeding site/severity and available drug level; stop anticoagulant and control the source.
- A normal PT/INR does not exclude clinically relevant apixaban/rivaroxaban activity, and INR is not a clearance test for a DOAC. Use an agent-appropriate calibrated level when available without delaying lifesaving treatment.
- For life-threatening/critical-site bleeding or urgent surgery, use the current agent-specific reversal pathway: vitamin K plus four-factor PCC for warfarin, idarucizumab for dabigatran, and andexanet alfa or four-factor PCC for factor-Xa inhibitors only when the severity, likely residual drug effect and local protocol justify it. Verify product, last dose, renal function, drug level if rapidly available, weight/maximum dose, thrombosis risk and redosing restrictions. A normal PT/INR does not exclude clinically relevant apixaban/rivaroxaban activity.
- GI-bleeding boundary: withhold the anticoagulant in major bleeding and prioritize resuscitation/source control; do not delay indicated endoscopy for correction. For VKA with hemodynamic instability, ESGE supports low-dose IV vitamin K plus IV PCC (FFP if PCC unavailable). ESGE 2026 says to consider DOAC reversal/PCC for severe ongoing UGIB; ESGE lower-GI guidance reserves it for ongoing bleeding/recurrent instability with hematology coordination. ACG-CAG suggests against routine andexanet or PCC in acute GI bleeding (conditional, very-low-certainty evidence). These recommendations differ; reserve reversal for an individualized, immediately threatening/uncontrolled bleed with plausible residual anticoagulant effect after urgent senior, hematology/pharmacy and GI discussion when feasible. Do not use reversal solely for an abnormal test or stable/minor bleeding. Do not routinely transfuse platelets to reverse antiplatelet drugs.
- Antiplatelets: distinguish primary from secondary cardiovascular prevention. For aspirin used only for primary prevention, temporarily hold during acute UGIB and reassess whether there is an ongoing indication. For secondary prevention, continue aspirin when feasible; if interrupted, resume promptly after hemostasis. With DAPT/recent coronary stent, continue aspirin if possible, discuss any P2Y12 interruption with cardiology, and restart promptly once safe; never stop both reflexively.
- Restart long-term anticoagulation after durable bleeding control unless a patient-specific contraindication remains. There is no universal day: balance source/stigmata and hemostasis against indication-specific thrombosis risk, renal function and drug onset, with GI plus cardiology/hematology input for high-risk cases. ESGE 2026 peptic-ulcer guidance says as soon as clinically indicated and explicitly states precise timing remains undefined; its 2021 lower-GI guideline suggests from day 7 for low thrombotic risk and earlier (preferably within 72 h) for high risk, both based on low/very-low-certainty evidence. Do not transplant one timing rule across upper, lower, variceal and small-bowel bleeding.
- Do not normalize laboratory values reflexively in nonmajor bleeding. Reassess hemostasis and document the restart/withholding plan and responsible clinician before disposition.

## medication-selection-safety

- Define the exact syndrome, therapeutic purpose, current value and target before
  selecting a drug. Distinguish treating the underlying disease from changing a
  physiologic number or treating a similarly named condition.
- When a user proposes an agent, state one of: recommended, not routinely indicated,
  conditional, contraindicated or uncertain. Give the decisive indication mismatch,
  contraindication or monitoring issue before offering a dose.
- For a recommendation, provide generic drug, route, initial dose, titration/redosing,
  maximum when applicable, organ-function adjustment, key contraindications,
  monitoring, hold/stop condition and reassessment interval. Do not imply a checklist
  is prescribing clearance.
- For every continuous infusion, state the total drug amount, compatible diluent,
  final volume and final concentration. Prefer a 100 mL or 200 mL final volume when
  clinically appropriate and compatible with the locally available formulation;
  do not invent compatibility or override a pharmacy/local standard concentration.
- Convert every continuous dose to a pump rate in mL/h. Show the arithmetic, the
  starting rate, each titration step in both dose units and mL/h, the titration
  interval, maximum or ceiling when applicable, and explicit hold/stop thresholds.
  For a weight-based infusion use:
  `mL/h = dose (mcg/kg/min) × weight (kg) × 60 ÷ concentration (mcg/mL)`.
- If weight or formulation is missing, do not invent it: provide the symbolic formula
  and request the missing value before presenting a patient-specific pump setting.
  A clearly labelled reference table may be added, but never presented as the patient's rate.
- Do not force bolus or intermittent medication into mL/h. For those, state the dose,
  stock strength, dilution when needed, final volume in mL and administration time/rate.
- Prefer titratable IV agents for time-critical hemodynamic control. Define both upper
  and lower safety bounds when cerebral, coronary or renal perfusion could be harmed;
  avoid an isolated target number without the syndrome and current pressure.
- Do not transfer targets or drugs among subdural hematoma, intraparenchymal hemorrhage,
  aneurysmal subarachnoid hemorrhage and ischemic stroke. Nimodipine is disease-modifying
  treatment for aneurysmal subarachnoid hemorrhage, not a general antihypertensive or
  routine treatment for isolated subdural hematoma. Nitrates are not default blood-
  pressure agents when intracranial mass effect or raised pressure is a concern.
- When an IV antihypertensive is unavailable, do not offer a name-only substitution.
  Route to `iv-antihypertensive-selection` and select by the organ-injury syndrome,
  heart rate/conduction, ventricular function, bronchospasm, pregnancy, renal/hepatic
  function and local formulation. Give a feasible alternative when one is supported
  and explain why it fits; if none is suitable or availability is unknown, state
  that limitation and the escalation plan rather than inventing availability.
  Explicitly reject nimodipine as a nicardipine substitute.
- In traumatic intracranial mass effect, treat hypertension as potentially compensatory until
  perfusion and raised-ICP physiology are assessed. Do not reflexively target SBP 140 mm Hg.
  Hypertonic saline for an ICP crisis is a weight-based bolus over a defined time, not a routine
  continuous infusion; preserve its bolus order even when a pump is used for delivery.
- If the evidence is update-sensitive, the exact formulation is unavailable locally,
  or the proposed use is off-label, verify an authoritative current source and local
  protocol before presenting the regimen as definitive.

## emergency-procedures

- Confirm indication, alternatives, contraindications, anatomy and asepsis; perform a time-out unless immediate action precludes it.
- Prepare analgesia/sedation, monitoring, backup equipment and explicit failure/rescue pathway.
- Confirm success with the appropriate clinical/imaging method, document complications and repeat neurovascular/respiratory/hemodynamic assessment after the procedure.
