# Validation report v1.34 working draft

## v1.34 shock, rhythm and cardiac arrest pathway audit
- Added six focused modules after confirming the previous bundle had only one brief combined adult-leaning rhythm/arrest pathway and lacked a general shock entry route.
- Reused existing etiologic pathways for septic, cardiogenic, hemorrhagic, anaphylactic, obstructive, adrenal and obstetric causes; no duplicate cause module added.
- Current checks are recorded after running structural, evidence-coverage and unit-test validation below. Clinical review and Portuguese local protocol reconciliation remain pending.

# Validation report v1.34 working draft

## Historical v1.33 pediatric pathways review
- Added five pediatric module IDs in the existing special-populations bundle; no new bundle.
- Router, evidence registry and pending queue updated; local Portugal/Azores protocols and clinician review pending.
- Validation results follow after execution.

# Validation report v1.32 working draft

## v1.32 small-bowel bleeding review
- Reused existing `lower-gi-bleeding` module; no new ID, dose or test case.
- Source/scope limitations are documented; ACG acute imaging guidance is from 2015.
- Structural, evidence and unit-test results are updated below.
- Local GI/IR workflow and formulary review, human clinical review and prospective validation remain pending.

# Validation report v1.31 working draft

## v1.31 GI antithrombotic review
- Reused existing upper-GI, lower-GI and anticoagulation-reversal module IDs; no cases or doses added.
- ESGE 2026/2021 and ACG-CAG 2022 source reconciliation recorded, including certainty and scope limitations.
- Structural/evidence/unit-test validation results are recorded below after execution.
- Portugal/Azores formulary/protocol review, human specialist review and prospective clinical validation remain pending.

# Validation report v1.30 working draft

## v1.30 enteral evidence review
- 93-module manifest and existing modules unchanged; no regression cases added.
- Evidence note and queue updated. No new medication regimen was promoted.
- scripts/validate_modules.py: PASS, 93 modules resolved.
- scripts/audit_evidence_coverage.py: PASS, 93/93 records, 34 green / 59 yellow / 0 red; no errors or warnings.
- python -m unittest discover -s tests -q: PASS, 58/58 tests.
- No local formulary or prospective clinical validation was performed.

## v1.29 mesenteric anticoagulation update
- No new module ID or regression case. Existing 93-module manifest retained.
- scripts/validate_modules.py: PASS, 93 modules resolved.
- scripts/audit_evidence_coverage.py: PASS, 93/93 records, 34 green / 59 yellow / 0 red; no errors or warnings.
- python -m unittest discover -s tests -q: PASS, 58/58 tests.
- Exact hospital anticoagulation nomogram, local monitoring and clinician review remain pending.

## v1.28 GI hemorrhage update
- 93 module IDs remain in the manifest; no new IDs or regression cases were added.
- Existing upper/lower GI and anticoagulation module routes were reused.
- `scripts/validate_modules.py`: PASS, 93 modules resolved.
- `scripts/audit_evidence_coverage.py`: PASS, 93/93 records, 34 green / 59 yellow / 0 red, no errors or warnings.
- `python -m unittest discover -s tests -v`: PASS, 58/58 tests.
- Evidence freshness check leaves yellow records due for external review by design; no DGS/INFARMED/local stock verification was performed.
- Clinical release review, local Portugal/Azores protocol/formulary checks, and prospective validation remain pending.

# Validation report v1.27 working draft

## v1.27 targeted update

- 93/93 manifest IDs resolve and have evidence records.
- All 58 existing unit tests pass; module and evidence-coverage audits pass.
- The targeted endocrine consensus comparison is documented in
  `updates/endocrine-consensus-review-2026-09-27.md`.
- No regression cases were added and no clinical-response/diagnostic-accuracy
  evaluation was performed for this content change. Clinician review and Portuguese
  product/formulary checks remain pending; this is not an installed release.

## v1.24 scope

Targeted source reconciliation completed for ESVS 2025 recommendations 37/40/41/45
and ESGE 2026 peptic-ulcer timing/PPI/escalation. Source access limitations reported
in v1.23 are resolved. The queue retains narrower regimen/detail follow-up.
No new patient cases or independent clinical-response evaluation were performed.

## v1.23 scope

Two GI/vascular modules and two synthetic cases added. Automated checks validate
structure and case metadata; they do not run clinical responses or establish
diagnostic accuracy. ESVS 2025 and the identified ESGE 2026 update remain pending
full-text reconciliation, explicitly recorded in the update queue.

## v1.22 scope

Two burn/smoke modules and two synthetic source-attributed cases were added.
Case validation checks provenance and module references, not actual clinical
answers. No clinical accuracy or patient-outcome claim follows from passing.

## Scope of validation

Automated tests cover module loading, shared preamble preservation, numerical
examples and contextual missing/invalid input handling. They do not evaluate
image recognition, sensitivity, specificity, diagnostic calibration or outcomes.
Manual image cases in `tests/image-review-cases.json` remain not_run until actual
authorized image-based evaluation with independent references is performed. One
ankle radiograph workflow was exercised after v1.3, but no independent report was
supplied, so it is not counted as an accuracy case. Prior successful demonstrations
are not clinical validation. Run current tests with:

`python3 -B -m unittest discover -s tests -p 'test_*.py' -v`

`python3 scripts/validate_modules.py`

`python3 scripts/validate_clinical_cases.py`

`python3 scripts/audit_evidence_coverage.py`

`python3 -B scripts/evaluate_image_cases.py tests/image-evaluation-example.json`

## v1.21 IV antihypertensive alternative audit

- 86/86 manifest modules resolve deterministically and have evidence records
- 23 source-attributed synthetic regressions include an unavailable-nicardipine case
- nimodipine cannot be selected as a general nicardipine replacement
- labetalol and clevidipine preserve verified concentrations, mL/h arithmetic,
  titration and cardiopulmonary/formulation contraindications
- drug selection branches by ICH, aortic syndrome, pulmonary edema/ACS, pregnancy
  and toxicologic physiology rather than treating the BP number alone
- these are structure and regression checks, not prospective clinical validation

## v1.20 neurovascular and spinal emergency audit

- 85/85 manifest modules resolve deterministically and have evidence records
- 22 source-attributed synthetic regressions include three new neurologic/spinal cases
- spontaneous ICH preserves immediate reversal, smooth BP control without SBP below
  130 mm Hg, neurosurgical escalation and non-routine platelet/seizure/ICP treatment
- acute spinal compression separates malignant, traumatic, infectious and hemorrhagic
  causes and limits dexamethasone to supported indications
- cauda equina/conus preserves emergency MRI/referral, PVR limitations and rejects a
  nominal 48-hour interval as permission to delay
- these are structure and regression checks, not prospective clinical validation

## v1.19 critical respiratory audit

- 82/82 manifest modules resolve deterministically and have evidence records
- 19 source-attributed synthetic regressions include three new respiratory cases
- acute severe asthma preserves controlled oxygen, adequate inhaled bronchodilator
  dosing, early steroid, selective magnesium and dynamic-hyperinflation safeguards
- COPD exacerbation preserves 88--92% oxygen pending gas, a five-day systemic
  steroid course, conditional antibiotics and early NIV for hypercapnic acidosis
- life-threatening hemoptysis is physiology-defined and prioritizes airway/lung
  protection plus embolization/surgical control rather than a volume threshold
- these are structure and regression checks, not prospective clinical validation

## v1.18 shock and advanced chest-pain audit

- 79/79 manifest modules resolve deterministically and have evidence records
- 16 source-attributed synthetic regressions include three new shock/chest-pain cases
- cardiogenic shock requires SCAI staging, serial perfusion endpoints, cause control,
  phenotype-guided vasoactive therapy and shock-team escalation
- acute aortic syndrome preserves beta-blocker-before-vasodilator sequencing,
  perfusion-aware BP targets, definitive imaging and type-specific intervention
- tamponade is defined by physiology rather than effusion size, avoids preload loss
  and hazardous positive pressure, and requires cause-appropriate urgent drainage
- norepinephrine, dobutamine, esmolol, labetalol and nicardipine reference preparations
  have independently testable concentrations and bedside mL/h arithmetic
- these are structure and regression checks, not prospective clinical validation

## v1.16 sourced safety audit

- 76/76 manifest modules in that release resolved deterministically
- 13 synthetic, de-identified regressions in that release had an authoritative source identity,
  expected module set, required actions and prohibited unsafe actions
- source provenance and module references are machine-validated
- all declared high-risk modules have an evidence-registry record
- unregistered modules remain yellow by default rather than inheriting false assurance
- sepsis timing distinguishes shock/probable sepsis from possible sepsis without shock
- cardiovascular checks preserve rhythm instability, syndrome-specific BP reduction,
  heart-failure phenotype and critical-valve boundaries
- status epilepticus, eclampsia, traumatic hemorrhage, upper GI bleeding and oral
  anticoagulant reversal received explicit safety gates
- these are structure and regression checks, not prospective clinical validation

## v1.10 targeted hypernatremia checks

- serum osmolality and effective tonicity use explicit unit-aware formulae
- measured versus calculated osmolality produces an osmolal gap
- urine osmolality and urine sodium are never fabricated from serum sodium alone
- urine sodium, urine potassium and urine volume produce electrolyte-free water clearance
- diagnostic interpretation distinguishes concentrated, intermediate and dilute urine

## v1.9 targeted emergency checks

- named electrolyte disorders route to ion-specific modules rather than generic replacement
- hyperkalemia distinguishes myocardial stabilization from potassium removal and monitors glucose
- sodium correction has symptom-based boluses, ceilings and an overcorrection rescue pathway
- IV potassium cannot be pushed or prescribed without mmol and final concentration
- suspected ruptured AAA cannot be excluded by POCUS or delayed for nonessential testing
- sedation requires a dedicated clinician, capnography and airway rescue capability
- RSI includes physiologic optimization, Plan A-D, first-pass strategy and post-intubation sedation

## v1.8 targeted intracranial mass-effect checks

- traumatic extra-axial hemorrhage with mass effect routes to an immediate neurosurgical pathway
- hyperosmolar treatment is a bridge and cannot replace or delay definitive evacuation
- spontaneous-ICH upper BP targets cannot be copied automatically into traumatic mass effect
- age-stratified SBP floors and cerebral perfusion are preserved
- adult 3% hypertonic saline remains a 5 mL/kg bolus over 5--20 minutes, not a continuous infusion
- nicardipine reference arithmetic is tied to a verified 20 mg/200 mL concentration
- the de-identified regression stores no patient image and does not establish diagnostic accuracy

## v1.7 targeted infusion checks

- every continuous infusion requires a final concentration and pump rate in mL/h
- 100 mL and 200 mL preparations are supported when compatible and locally appropriate
- weight-based arithmetic cannot invent a missing patient weight or formulation
- titration includes dose units, mL/h, interval, ceiling and hold/stop thresholds
- bolus and intermittent drugs are not misleadingly converted into continuous rates
- norepinephrine 8 mg/100 mL at 0.1 mcg/kg/min for 80 kg = 6 mL/h
- norepinephrine 8 mg/200 mL at 0.1 mcg/kg/min for 80 kg = 12 mL/h

## v1.6 targeted respiratory regression checks

- shock cannot be dismissed because heart rate is within a usual reference range
- high clinical suspicion of tension pneumothorax does not wait for radiography
- POCUS is used only when immediately available without delaying decompression
- decompression includes technique/site verification, rescue planning, reassessment
  and definitive drainage rather than being treated as a completed pathway
- absent improvement triggers equipment review and renewed obstructive-shock differential
- the scenario is synthetic/de-identified and tests instructions, not patient outcomes

## v1.5 targeted regression checks

- brain CT/MRI instructions require explicit extra-axial, ventricular, cisternal,
  midline, mass-effect and herniation review before reassurance
- screen-recorded stacks require original-quality representative and contiguous frames
- absent orientation cannot silently become patient laterality
- medication selection must state indication, target, route, titration, monitoring
  and stop criteria
- nimodipine and nitrate examples test disease-indication boundaries rather than
  serving as a fixed formulary
- the triggering clinical case is recorded only as an abstract regression scenario;
  no patient media is retained in the skill
- these checks validate instructions and structure, not diagnostic sensitivity or
  medication safety outcomes

## v1.4 image checks

- all eight image modality routes resolve through the manifest
- attachment recovery has a single safe retry and forbids unrelated-file substitution
- image reports have a machine-readable completeness schema
- radiographs request views and laterality marker; POCUS states still/cine/compression scope
- evaluation exposes critical sensitivity, false reassurance, abstention and undertriage
- every metric reports numerator and denominator and excludes unreferenced cases explicitly
- synthetic evaluation data are labelled as non-clinical
- clinical/vision accuracy remains pending independent representative evaluation

## Structural checks
- SKILL.md present
- router present
- module index present
- response templates present
- evidence policy present
- calculators present
- test cases present

## Arithmetic checks
- 8 mg norepinephrine in 100 mL, 80 kg, 0.1 mcg/kg/min -> 6 mL/h
- weight-based dosing supports optional maximum dose cap

## Stability goals
v1.0 is the first consolidated stable release.
Further versions should prioritize validation and targeted refinement over uncontrolled module growth.

## v1.2 modular completeness checks
- all 54 manifest IDs resolve to existing bundle files
- each ID has exactly one matching `## module-id` section
- orphan and duplicate sections fail validation
- route lines must resolve to at least one known module
- unknown module loading fails explicitly rather than silently
- official Skill Creator quick validation passes

## v1.1 Living Evidence checks
- evidence registry present
- update policy present
- pending update queue present
- status model green/yellow/red defined
- high-risk 30-day review cadence defined
- stable modules cannot be silently overwritten
- registry checker script present
- update record generator present
- regression tests added for stale evidence handling
## v1.31 execution results
- `scripts/validate_modules.py`: PASS, 93 modules resolved.
- `scripts/audit_evidence_coverage.py`: PASS, 93/93 evidence records; 33 green / 60 yellow / 0 red; no errors or warnings.
- `python -m unittest discover -s tests -q`: PASS, 58/58 tests.
- Archive integrity (`unzip -t`) and SHA-256 are recorded after packaging.
## v1.32 execution results
- `scripts/validate_modules.py`: PASS, 93 modules resolved.
- `scripts/audit_evidence_coverage.py`: PASS, 93/93 evidence records; 33 green / 60 yellow / 0 red; no errors or warnings.
- `python -m unittest discover -s tests -q`: PASS, 58/58 tests.
- Local GI/IR pathway, human review and prospective clinical validation were not performed.
## v1.34 execution results
- `scripts/validate_modules.py`: PASS, 104 modules resolved.
- `scripts/audit_evidence_coverage.py`: PASS, 104/104 evidence records; 31 green / 73 yellow / 0 red; no errors or warnings.
- `python -m unittest discover -s tests -q`: PASS, 58/58 tests (manifest cardinality assertion updated to 104).
- Source checksum audit, ZIP integrity and archive SHA-256 are recorded after packaging.
- No local Portugal/Azores pediatric protocol or formulary check and no prospective clinical validation were performed.

## v1.34 final verification (2026-09-28)
- `scripts/validate_modules.py`: PASS, 104 modules resolved.
- `scripts/audit_evidence_coverage.py`: PASS, 104/104 records; 31 green, 73 yellow, 0 red.
- `python -m unittest discover -s tests -q`: PASS, 58 tests.
- `scripts/check_evidence_registry.py`: completed; outputs review-due status for yellow/high-priority records, no release approval implied.
- `unzip -t`: PASS.
- Clinical performance and local protocol validation are not established by these technical checks.
