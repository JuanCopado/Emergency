# CURRENT_STATE — Competencia Médica

Fecha de comprobación: 28/09/2026.
Fuente comprobada en esta sesión: ZIP subido v1.26. No se ha inspeccionado ni modificado la carpeta de la competencia instalada; por tanto, este estado no afirma que la v1.30 esté instalada o visible en Plugins.

## Estado verificado
- Paquete original recibido: **v1.26 — Endocrine Emergencies**. Copia de trabajo actual: propuesta **v1.34**, no instalada.
- **104** IDs únicos en el índice del paquete; **104/104** resuelven en los bundles.
- Evidencia registrada: **104/104**; 31 green, 73 yellow, 0 red.
- Línea base v1.26: **58 pruebas unitarias** y **27 regresiones con fuentes**. En la propuesta v1.34 pasan 58 pruebas unitarias; las 104 rutas resuelven y la auditoría de cobertura registra 104/104 (31 green, 73 yellow, 0 red). El test de manifiesto incluye las once rutas incorporadas desde v1.26. Estos controles no equivalen a validación clínica prospectiva.
- Los casos de regresión y las pruebas estructurales no son evaluación ciega de
  respuestas, validación clínica prospectiva ni prueba de precisión de imágenes.
- Flujos de imagen: puerta de entrada común y **9 IDs de modalidad** (radiografía
  musculoesquelética y torácica, POCUS, ECG, gasometría, piel/herida, TC/RM,
  oftalmología y otra imagen); no hay un modelo diagnóstico entrenado propio.

## Regla de continuidad
El índice de la competencia instalada manda. **No volver al paquete de 63** ni
fijar 85 como el total actual. La cifra 85 está documentada en v1.20; las versiones
v1.21–v1.26 añadieron módulos. Si se cambia el código, recalcular total y cobertura.

## Decisiones clínicas y de presentación
- Responder en español salvo petición de otro idioma.
- Para perfusiones: dosis, dilución compatible (100 o 200 mL si procede),
  concentración final, aritmética, **mL/h**, titulación y monitorización.
- Para bolos/intermitentes: dosis, volumen y tiempo; no convertirlos artificialmente
  en perfusión continua. Verificar peso, función renal, alergias y contraindicaciones.
- Ofrecer alternativas según síndrome y disponibilidad local comprobada.
  **Nimodipino no sustituye a nicardipino** como antihipertensivo general.
- En Portugal/Azores consultar DGS, INFARMED y protocolo regional/local antes de
  afirmar conformidad o disponibilidad; el acceso previo al portal DGS dio 403.
- Las recomendaciones clínicas cambiantes requieren cotejo actualizado antes de
  presentarlas como definitivas; las modificaciones pasan por revisión humana.

## Trabajo clínico reciente y continuación
- v1.20: hemorragia intracerebral espontánea, compresión medular, cola de caballo.
- v1.21: selección de antihipertensivos IV cuando no haya nicardipino.
- v1.22: grandes quemados e inhalación de humo.
- v1.23–v1.24: hemorragia digestiva baja, isquemia mesentérica y reconciliación
  focal con ESVS 2025 / ESGE 2026.
- v1.25: flujo para verificar fuentes DGS/INFARMED y contexto portugués.
- v1.26: crisis suprarrenal, tormenta tiroidea y coma mixedematoso.
- Trabajo completado en la copia de trabajo, propuesta v1.27: reconciliación focal con consensos conjuntos
  ETA/BTA/Society for Endocrinology/Welsh Endocrine and Diabetes Society de 2026
  para tormenta tiroidea (ETJ-26-0043) y coma mixedematoso (ETJ-26-0044). En la
  tormenta se añadió la pauta de hidrocortisona del consenso, separada de ATA 2016,
  seguridad hepática/PTU, control de potasio y escalada. En coma mixedematoso, las
  pautas IV cotejadas concuerdan con el módulo; no se añadió pauta enteral no
  verificada. Resultado de auditoría: 93/93 resuelven; evidencia 93/93 (34 green,
  59 yellow, 0 red); 58/58 pruebas pasan. Detalle: `updates/endocrine-consensus-review-2026-09-27.md`.
- Pendientes inmediatos: revisión clínica humana del borrador; comprobación local
  DGS/INFARMED/formulario Azores y disponibilidad; detalle enteral de levotiroxina
  si no hay IV. El portal DGS previamente devolvió 403; ninguna norma individual
  consta aquí como revisada.
- Propuesta v1.28: revisión ampliada de hemorragia digestiva integrada en las rutas existentes. `upper-gi-bleeding` ahora incluye estabilización/riesgo, vía aérea selectiva, procinéticos selectivos, estigmas Forrest, hemostasia/rescate y vía variceal separada. La ruta existente `lower-gi-bleeding` fue cotejada: CTA/embolización, colonoscopia no urgente tras estabilización, reversión selectiva y TXA no rutinario ya cubiertos. Sin módulo nuevo; índice real sigue en 93. Ver `updates/gi-bleeding-review-2026-09-28.md`.
- Pendientes GI: revisión clínica humana, protocolo/formulario/stock local de Portugal-Azores, conciliación detallada del reinicio/reversión antitrombótico y diagnóstico de intestino delgado tras endoscopia alta/baja negativa. Mantener distinción entre recomendaciones de guías y protocolo local.
- Propuesta v1.29: revisión focal de anticoagulación en isquemia mesentérica aguda con ESVS 2025/WSES 2022. Clarifica UFH/LMWH para MVT, duración 3–6 meses y terapia prolongada según riesgo, escalada por peritonitis/deterioro, distinción NOMI/arterial y ausencia de nomograma UFH universal en esas guías. No inventa dosis o mL/h. Se conserva el ID existente. Ver updates/mesenteric-anticoagulation-review-2026-09-28.md. Quedan validación humana y protocolo local de dosis/monitorización/procedimientos.
- Propuesta v1.30: revisión focal de la alternativa enteral en coma mixedematoso. No se añadió dosis: el consenso conjunto 2026 conserva carga IV y contempla transición oral al recuperar plenamente la conciencia; una serie unicéntrica retrospectiva (14 casos, edades 11–82) no basta para adoptar la carga oral/taper como pauta general adulta. Se mantiene revisión especialista y local. Ver updates/myxedema-enteral-review-2026-09-28.md.
- Propuesta v1.31: reconciliación focal de reversión/reinicio antitrombótico en hemorragia digestiva, usando módulos existentes (sin ID duplicado). Se anotan diferencias ESGE/ACG-CAG sobre reversión DOAC (certeza baja/muy baja), algoritmo selectivo según gravedad/efecto residual y reglas de aspirina/DAPT; el momento de reiniciar anticoagulación queda individualizado y específico por fuente. Ver `updates/gi-antithrombotic-review-2026-09-28.md`. Revisión clínica humana y protocolo/formulario local pendientes.
- Propuesta v1.32: extensión de diagnóstico del intestino delgado tras endoscopias alta/baja no diagnósticas, integrada en `lower-gi-bleeding` sin crear duplicado. Se distingue hemorragia inestable (reanimación/CTA-angiografía) de paciente estable (cápsula precoz, idealmente <48 h si segura), riesgo de retención, enteroscopia dirigida y conducta tras cápsula negativa. La rama de imagen aguda ACG procede de guía 2015 y requiere revisión local GI/IR. Ver `updates/small-bowel-bleeding-review-2026-09-28.md`.
- Propuesta v1.33: se crean cinco rutas pediátricas específicas dentro del bundle existente `special-populations.md`: lactante febril ≤90 días, bronquiolitis, crup, deshidratación/choque y estatus epiléptico convulsivo (1 mes–18 años). El índice sube de 93 a 98 IDs; se mantiene `pediatric-emergencies` genérico. Fuentes/alcances, exclusiones y pendientes locales están en `updates/pediatric-pathways-review-2026-09-28.md`. Revisión humana y protocolos/formulario Portugal-Azores pendientes.
- Siguiente expansión tras esa cola: rutas pediátricas específicas —lactante febril,
  bronquiolitis, crup, deshidratación/choque y estatus epiléptico pediátrico— porque
  el índice actual solo tiene `pediatric-emergencies` general; no duplicar otros
  módulos ya presentes.

- Propuesta v1.34: auditoría de shock y reanimación. Causas de shock cubiertas en módulos existentes: hipovolémico/hemorrágico (`trauma-major-hemorrhage`, `pediatric-dehydration-shock`), distributivo (séptico, anafiláctico, suprarrenal; neurogénico referido con cautela), cardiogénico, obstructivo (TEP, taponamiento, neumotórax a tensión) y mixto. Se añadió un módulo de evaluación/ruta para shock indiferenciado y otro marco pediátrico que deriva a causas existentes. El módulo único previo `arrhythmias-cardiac-arrest` era breve y no separaba edad ni algoritmos; se añadieron `adult-arrhythmias`, `adult-cardiac-arrest`, `pediatric-arrhythmias` y `pediatric-cardiac-arrest`, conservando el ID anterior como puerta de selección. ERC/RCUK 2025 comprobados; revisión humana, dosis/energías de tarjetas locales y protocolos Portugal/Azores pendientes. Ver `updates/shock-arrhythmia-arrest-review-2026-09-28.md`.

## Casos y límites
Los casos de hematoma subdural, neumotórax a tensión, IAMCEST, TEP, sepsis,
hemorragia digestiva e infección grave ayudaron a definir reglas y regresiones.
No atribuir a todos ellos una evaluación independiente o real de respuestas.
Nunca describir la interpretación visual como clínicamente validada. La copia
actualizada de este ZIP es un borrador de trabajo, no una instalación publicada.
